package com.example.map;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DreySchedule extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drey_schedule);
    }
}
