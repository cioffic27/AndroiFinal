package com.example.map;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void onClickSS(View view){
        Intent ss = new Intent(this,StudentCenter.class);
        startActivity(ss);
    }

    public void onClickDrey(View view){
        Intent drey = new Intent(this,Dreyfus.class);
        startActivity(drey);
    }

    public void onClickMon(View view){
        Intent mon = new Intent(this,Mon.class);
        startActivity(mon);
    }
    public void onClickScience(View view){
        Intent sci = new Intent(this,Science.class);
        startActivity(sci);
    }
    public void onClickZen(View view){
        Intent zen = new Intent(this,Zen.class);
        startActivity(zen);
    }
    public void onClickMan(View view){
        Intent man = new Intent(this,Mansion.class);
        startActivity(man);
    }
    public void onClickHelp(View view){
        Intent help = new Intent(this,Help.class);
        startActivity(help);
    }

}
